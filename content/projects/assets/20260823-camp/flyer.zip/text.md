# ChaosZeltZone 2026

ChaosZeltZone ist gemeinsames Camping für Menschen 
aus allen Ecken der ChaosZone und Friends.
Auf einem ehemaligen LPG-Gelände mit Lost-Place-Flair.
Mit Workshops, Sessions und viel Raum für Natur und 
Kultur gestalten wir den Ort gemeinsam.

WANN
19.  - 23. August 2026

WO
CZZ in Krebes, Vogtlandkreis
Burgsteinstraße 15A, 08538 Weischlitz

INFOS UND TICKETS
www.thereisno.camp


